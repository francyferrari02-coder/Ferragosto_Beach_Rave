// ═══════════════════════════════════════════════════════════════════════
//  FESTA DI FERRAGOSTO — Google Sheet log + live people counter
//
//  Logs every RSVP and returns a running total of people coming
//  (each person + the friends they're bringing) for the website counter.
//
//  SETUP:
//    1. Create a blank Google Sheet
//    2. Extensions → Apps Script
//    3. Paste this entire file, save
//    4. Deploy → New deployment → type: Web app
//         Execute as: Me · Access: Anyone
//    5. Copy the Web app URL into the site's CONFIG.rsvpEndpoint
// ═══════════════════════════════════════════════════════════════════════

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var data = JSON.parse(e.postData.contents);

    if (sheet.getLastRow() === 0) {
      sheet.appendRow(['Timestamp', 'Type', 'Name', 'Attending', 'Headcount', 'Total people', 'Note']);
      var h = sheet.getRange(1, 1, 1, 7);
      h.setFontWeight('bold');
      h.setBackground('#13314F');
      h.setFontColor('#FBF6EC');
      sheet.setFrozenRows(1);
      sheet.setColumnWidth(1, 160);
      sheet.setColumnWidth(2, 90);
      sheet.setColumnWidth(3, 180);
      sheet.setColumnWidth(4, 120);
      sheet.setColumnWidth(5, 110);
      sheet.setColumnWidth(6, 110);
      sheet.setColumnWidth(7, 260);
    }

    var ts = new Date(data.timestamp);
    var formatted = Utilities.formatDate(ts, 'Europe/Rome', 'dd MMM yyyy · HH:mm');

    sheet.appendRow([
      formatted,
      data.type || 'RSVP',
      data.name || '',
      data.attendance || '',
      data.extras || '',
      data.totalPeople || 1,
      data.note || ''
    ]);

    // Color "Forse" / "Maybe" rows differently from confirmed
    var lastRow = sheet.getLastRow();
    var rowRange = sheet.getRange(lastRow, 1, 1, 7);
    var att = (data.attendance || '').toLowerCase();
    if (att.indexOf('forse') !== -1 || att.indexOf('maybe') !== -1) {
      rowRange.setBackground('#FBF3DE');  // soft sand = maybe
    } else {
      rowRange.setBackground('#E6F0F3');  // soft sea = confirmed
    }

    return ContentService
      .createTextOutput(JSON.stringify({ status: 'ok' }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// GET: returns live count of total confirmed people (for the website counter)
//   ?action=count  → { total: N, confirmed: N, maybe: N, entries: N }
function doGet(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var lastRow = sheet.getLastRow();
  var totalPeople = 0, maybePeople = 0, entries = 0;

  if (lastRow > 1) {
    var rows = sheet.getRange(2, 4, lastRow - 1, 3).getValues(); // Attending, Headcount, Total people
    rows.forEach(function(r) {
      var attending = String(r[0]).toLowerCase();
      var total = Number(r[2]) || 1;
      entries++;
      if (attending.indexOf('forse') !== -1 || attending.indexOf('maybe') !== -1) {
        maybePeople += total;
      } else {
        totalPeople += total;
      }
    });
  }

  var payload = {
    total: totalPeople,        // confirmed people (each guest + their +N)
    confirmed: totalPeople,
    maybe: maybePeople,
    entries: entries
  };

  // Support JSONP if a callback is provided (avoids any CORS issues)
  var callback = e && e.parameter && e.parameter.callback;
  if (callback) {
    return ContentService
      .createTextOutput(callback + '(' + JSON.stringify(payload) + ')')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }

  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}
